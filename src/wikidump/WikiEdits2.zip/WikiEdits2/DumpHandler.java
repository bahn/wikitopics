
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.Stack;
 
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
 


import java.text.ParseException;

	 

	class DumpHandler extends DefaultHandler {
 
		private final Namespaces namespaces = new Namespaces(); 
		private static StringConstant _SC ;
		private static PageHandler PAGE_HAND = new PageHandler();
		private final Stack<String> elementStack = new Stack<String>();
		
		protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(_SC.DATE_FORMAT_STRING);
		private static final DateFormat TIMESTAMP_DUMP_FORMAT= new SimpleDateFormat
										(_SC.DATE_FORMAT_STRING + "'T'" + _SC.TIME_FORMAT_STRING + "'Z'z");

		
		/* timestamp for the 
		 ** 
		 *startdate provided*/
		private Date beginTimestamp = null;
		
		/*timestamp for the enddate provided including 
		 the last minute of last hour
		 */
		private Date endTimestamp = null;
		
		/* lastMonth's last date date timestamp*/
		private Calendar lastMonth = Calendar.getInstance();
		private Date timestamp = null;
		
		private int editsInLastMonth = 0;		
		/* Total number of revision*/
		private int revisionCounter = 0;
		 
		/* total number of edits performed*/
		private int totalEdits = 0;
 
		private int totalEditsInPeriod = 0;
		/* pages to be stored with a minimum number of edits*/
		private int minimumEdits = 0;
 
		/* number of top K pages required required*/
		private int limit = 0;
		private int ns = 0;
		private String namespace = "";
 
		private String pageTitle = "";

		private Page page = null;
 
		/* array of Pages*/
		private Page[] pages = null;
 

		private String timestampString = "";
 
		private boolean ignoreRevision = false;
 
		private int timestampParseExceptionCount = 0;
 
		final static private PagesComparator PAGES_COMPARATOR = new PagesComparator();
		
		int pageCounter = 0;
		
		public Page[] getPages() {
			return pages;
		}				
		
		public Date getBeginTimestamp() {
			return beginTimestamp;
		}
 
		public Date getEndTimestamp() {
			return endTimestamp;
		}
 
		public void setLimit(int limit) {
			this.limit = limit;
		}
 

		public void startDocument() throws SAXException {

			beginTimestamp = getDateProperty(_SC.BEGIN_DATE_PROPERTY_KEY);
			final Calendar endTimestampCalendar = Calendar.getInstance();
			endTimestampCalendar.setTime(getDateProperty(_SC.END_DATE_PROPERTY_KEY));
			endTimestampCalendar.add(Calendar.HOUR, 23);
			endTimestampCalendar.add(Calendar.MINUTE, 59);
			endTimestampCalendar.add(Calendar.SECOND, 59);
			endTimestamp = endTimestampCalendar.getTime();
			lastMonth.setTime(endTimestamp);
			if (endTimestampCalendar.get(Calendar.DATE) != endTimestampCalendar.getActualMaximum(Calendar.DATE)) {
				lastMonth.roll(Calendar.MONTH, -1);
			}
			pages = new Page[(int)(limit * 1.5)];
			
			
			String minimuEditsText = System.getProperty(_SC.MINIMUM_EDITS_PROPERTY_KEY, "15");
			minimumEdits = Integer.parseInt(minimuEditsText);
		}
 
		public void endDocument() throws SAXException {
			System.err.println("Processed: " + revisionCounter);
			System.err.println("As of the last month"
					+ " (" + new SimpleDateFormat(_SC.YEARMONTH_FORMAT_STRING).format(beginTimestamp) + "),"
					+ " the Wikipedia received "
					+ (int)(editsInLastMonth / lastMonth.getActualMaximum(Calendar.DATE))
					+ " edits a day.");
			System.err.println("The " + totalEdits + " total edits made to the Wikipedia.");
//			System.err.println("Timestamp ParseException: " + timestampParseExceptionCount + " occured.");
		}
 
		private static Date getDateProperty(String key) throws SAXException {
			String property = System.getProperty(key);
			Date date ;
			try {
				date= DATE_FORMAT.parse(property);
				
			} catch (ParseException e) {
				throw new SAXException(e);
			}
			return date;
		}
 
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
			String name = localName.equals("") ? qName : localName;
			elementStack.push(name);
			if (name.equals("namespace")) {
				String key = "";
				try {
					key = atts.getValue("key");
					ns = Integer.parseInt(key);
				} catch (NumberFormatException e) {
					throw new SAXException("ns: " + key, e);
				}
			}
		}
 
	
 
		public void endElement(String uri, String localName, String qName) throws SAXException {
			final String name = elementStack.pop();
			if (name.equals("namespace")) {
				namespaces.add(namespace, ns);
				ns = 0;
				namespace = "";
			} else if (name.equals("page")) {
				if (page.getEdits() < minimumEdits) {
					return;
				}
				if (pageCounter <= (pages.length - 1)) {
					pageCounter ++;
					pages[pageCounter - 1] = page;
				} else if (pageCounter > (pages.length - 1)) {
					final Page lastPage = pages[pages.length - 1];
					if (page.getEdits() > lastPage.getEdits()) {
						pageCounter ++;
						pages[pages.length - 1] = page;
					}
				}
				if (pageCounter >= limit) {
					Arrays.sort(pages, PAGES_COMPARATOR);
				}
			} else if (name.equals("title")) {
				page = new Page(pageTitle, namespaces.ns(pageTitle));
				pageTitle = "";
			} else if (name.equals("timestamp")) {
				ignoreRevision = false;
				try {
					timestamp = TIMESTAMP_DUMP_FORMAT.parse(timestampString + "UTC");
					timestampString = "";
				} catch (ParseException e) {
					timestampParseExceptionCount++;
					ignoreRevision = true;
				}
				
			} else if (name.equals("revision")) {
				if (ignoreRevision) {
					return;
				}
				PAGE_HAND.incrementTotalAndDayEdits(page, timestamp);
//				if (timestampBeroreOrEquals(timestamp)) {
//					PAGE_HAND.incrementTotalEdits(page);
//					if (timestampIsInPeriod(timestamp)) {
//						PAGE_HAND.incrementEdits(page);
//					}
//				}
				final Calendar calendar = Calendar.getInstance();
				calendar.setTime(timestamp);
				if (calendar.get(Calendar.YEAR) == lastMonth.get(Calendar.YEAR)
						&& calendar.get(Calendar.MONTH) == lastMonth.get(Calendar.MONTH)) {
					editsInLastMonth ++;
				}
				if (timestampBeroreOrEquals(timestamp)) {
					totalEdits ++;
					if (timestampIsInPeriod(timestamp)) {
						totalEditsInPeriod ++;
					}
				}
				timestamp = null;
				revisionCounter++;
				final int LOG_INTERVAL = 10000;
				if (revisionCounter % LOG_INTERVAL == 0) {
					System.err.println("Processed: " + revisionCounter);
				}
			}
		}
 
		private boolean timestampIsInPeriod(Date timestamp) {
			return ( timestamp.equals(beginTimestamp) || timestamp.after(beginTimestamp) )
					&& timestampBeroreOrEquals(timestamp);
		}
 
		private boolean timestampBeroreOrEquals(Date timestamp) {
			return ( timestamp.before(endTimestamp) || timestamp.equals(endTimestamp) );
		}
 
		public void characters (char[] ch, int start, int length) {
			try {
				final String elementName = elementStack.peek();
				final String string = new String(ch, start, length);
				if (elementName.equals("namespace")) {
					namespace += string;
				}
				if (elementName.equals("title")) {
					pageTitle += string;
				}
				if (elementName.equals("timestamp")) {
					timestampString += string;
//					if (revisionCounter % 10000 == 0) {
//						System.err.println(ch.length);
//					}
				}
			} catch (EmptyStackException e) {
				// NOP
			} catch (IndexOutOfBoundsException e) {
				// NOP
			}
		}
 
	}