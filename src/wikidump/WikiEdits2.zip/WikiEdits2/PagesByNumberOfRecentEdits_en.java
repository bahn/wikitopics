import java.text.SimpleDateFormat;


public class PagesByNumberOfRecentEdits_en extends PagesByNumberOfRecentEdits {
 
	
	protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(_SC.DATE_FORMAT_STRING);
	/**
	 * The main() method for this application.
	 * @param args command-line arguments
	 */
	public static void main(String[] args) {
		//#java -Dbegin.date=2008-04-01 -Dend.date=2008-04-30 -Dlimit=5000 -Dmin.edits=80 PagesByNumberOfRecentEdits_en enwiki-20080501-stub-meta-history.xml.gz > result.txt
		new PagesByNumberOfRecentEdits_en().execute(args);
		
	}
 
	protected String getWikiName() {
		return "enwiki";
	}
	

	protected void printHeader() {
		getWriter().print("Period: "
					+ DATE_FORMAT.format(getBeginTimestamp())
					+ " &mdash; "
					+ DATE_FORMAT.format(getEndTimestamp())
					+ " (UTC)");
		getWriter().println();
		getWriter().println();
	}
 
	protected String getTableHeader() {
		return "Rank !! Page !! [[Wikipedia:Namespace|Namespace]] !! Recent Edits !! Total Edits";
	}
 
}