import java.util.Comparator;

	 class PagesComparator implements Comparator<Page> {
		public int compare(Page page1, Page page2) {
			if (page1 == null || page2 == null) {
				if (page1 == null && page2 == null) {
					return 0;
				}
				if (page1 == null) {
					return 1;
				}
				if (page2 == null) {
					return -1;
				}
			}
			if (page1.getEdits() != page2.getEdits()) {
				return page2.getEdits() - page1.getEdits();
			} else {
				return page2.getTotalEdits() - page1.getTotalEdits(); 
			}
		}
	}