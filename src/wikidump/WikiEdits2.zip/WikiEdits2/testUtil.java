import java.text.SimpleDateFormat;
import java.util.Date;


public class testUtil {

	public static void main(String argv[]) {
		
		Date time = new Date();
		System.out.println(DateUtilWiki.parseTextFromDate(time));
		System.out.println( );
	}
}
