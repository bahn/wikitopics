import java.util.Date;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import sun.text.Trie.DataManipulate;

class Page {
	
	 
	private final String title;
 
	private SortedMap<String,Long> dateMapCounts = null;
	
	private final int ns; 
	
	private int edits;
 
	/* edits make before the end time, but from the start*/
	private int totalEdits;
 
	public SortedMap<String, Long> getDateMapCounts() {
		return dateMapCounts;
	}

	public void setDateMapCounts(SortedMap<String, Long> dateMapCounts) {
		this.dateMapCounts = dateMapCounts;
	}

	public int getEdits() {
		return edits;
	}

	public void setEdits(int edits) {
		this.edits = edits;
	}

	public int getTotalEdits() {
		return totalEdits;
	}

	public void setTotalEdits(int totalEdits) {
		this.totalEdits = totalEdits;
	}

	public String getTitle() {
		return title;
	}

	public int getNs() {
		return ns;
	}

	public Page(String title, int ns) {
		this.title = title;
		this.ns = ns;
		dateMapCounts = new TreeMap<String, Long>();
	}
 

}