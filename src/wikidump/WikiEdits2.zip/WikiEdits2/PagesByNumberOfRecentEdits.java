import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;
import java.util.zip.GZIPInputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;
 
public abstract class PagesByNumberOfRecentEdits {
 
	protected abstract String getWikiName();
	protected abstract String getTableHeader();
	protected abstract void printHeader();	
	protected static StringConstant _SC ;
	
	private int limit = 0;
 
	private final Date dateStarted =  new Date();
	private Date beginTimestamp = null;
	private Date endTimestamp = null;
 
	protected Date getBeginTimestamp() {
		return beginTimestamp;
	}
 
	protected Date getEndTimestamp() {
		return endTimestamp;
	}
	
	private PrintWriter writer = null;
	 
	protected PrintWriter getWriter() {
		return writer;
	}	
	
	protected String getSortable() {
		return _SC.SORTABLE;
	}
	
	
 	
	private void printUsage() {
		System.err.print("Usage (example): java -D" + _SC.BEGIN_DATE_PROPERTY_KEY + "=2008-04-01"
											+ " -D" + _SC.END_DATE_PROPERTY_KEY + "=2008-04-30"
											+ " -D" + _SC.LIMIT_PROPERTY_KEY + "=5000"
											+ " -D" + _SC.MINIMUM_EDITS_PROPERTY_KEY + "=15");
		
		System.err.print(" " + getClass().getName());
		System.err.print(" " + getWikiName() + "-20080501-stub-meta-history.xml.gz");
		System.err.print(" > result.txt");
		System.err.println();
	}

	
	
	protected void execute(String[] args) {
 
		try {
			final int VALID_ARGUMENT_LENGTH = 1;
			if (args.length < VALID_ARGUMENT_LENGTH) {
				printUsage();
				System.exit(1);
			}
			writer = new PrintWriter(new OutputStreamWriter(System.out, "UTF-8"));
			System.err.println("Started. " + dateStarted);
			
			String limitText = System.getProperty(_SC.LIMIT_PROPERTY_KEY, "5000");
			limit = Integer.parseInt(limitText);
			
			final File dumpFile = new File(args[0]);
			fileNameCheck(dumpFile);
			
			/* this is used to handle the SAXParser defaults events*/
			final DumpHandler dumpHandler = new DumpHandler();
			dumpHandler.setLimit(limit);
			
			/* makes a new instance of SAXParser from the Factory
			 * and provides to the parse method the DefualtHandler
			 */
			SAXParserFactory.newInstance().newSAXParser().parse(
					new GZIPInputStream(new FileInputStream(dumpFile)), dumpHandler);
			
			/* get the pages after being stored in the dumpHandler*/
			final Page[] pages = dumpHandler.getPages();
			
			
			beginTimestamp = dumpHandler.getBeginTimestamp();
			endTimestamp = dumpHandler.getEndTimestamp();
			print(pages);
		} catch (NumberFormatException e) {
			System.err.println("The specified system property \"" + _SC.LIMIT_PROPERTY_KEY + "\" is not a valid integer.");
			System.err.println(e);
			System.exit(1);
		} catch (FileNotFoundException e) {
			System.err.println(e);
			System.exit(1);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (SAXException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		} finally {
			final Date dateEnded = new Date();
			System.err.println("Ended. " + dateEnded);
			final SimpleDateFormat dateFormat = new SimpleDateFormat(_SC.TIME_FORMAT_STRING);
			dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			System.err.println("Elapsed: " + dateFormat.format(new Date(dateEnded.getTime() - dateStarted.getTime())));
		}
 
	}
 
	
 
	private void print(Page[] pages) {
		try {
			printHeader();
			Arrays.sort(pages, new PagesComparator());
			writer.print("{| class=\"wikitable" + getSortable() + "\"");
			writer.println();
			writer.print("! " + getTableHeader());
			writer.println();
			int rank = 0;
			int prevCount = 0;
			int sameRank = 0;
			for (Page page : pages) {
				final String rankText;
				if (rank == 0) {
					rank++;
					sameRank = 1;
				} else if (page.getEdits() < prevCount) {
					rank += sameRank;
					sameRank = 1;
				} else {
					sameRank++;
				}
				rankText = Integer.toString(rank);
				prevCount = page.getEdits();
				if (rank > limit) {
					break;
				}
				writer.print("|-");
				System.out.print("|-");
				writer.println();
				writer.print("| " + rankText);
				System.out.print("| " + rankText);
				writer.print(" || ");
				System.out.print(" || ");
				writer.print("[[:" + page.getTitle() + "]]");
				System.out.print("[[:" + page.getTitle() + "]]");
				writer.print(" || ");
				System.out.print(" || ");
				writer.print(page.getNs());
				System.out.print(page.getNs());
				writer.print(" || ");
				writer.print(page.getEdits());
				System.out.print(page.getEdits());
				writer.print(" || ");
				writer.print(page.getTotalEdits());
				System.out.print(page.getTotalEdits());
				writer.println();
			}
			writer.print("|}");
			writer.println();
		} finally {
			writer.flush();
		}
	}
	
	private void fileNameCheck(File file) {
		if (!file.getName().startsWith(getWikiName())) {
			System.err.println("WARNING: The specified file name '" + file.getName() + "' does not start with '" + getWikiName() + "'.");
			try {
				Thread.sleep(5000);
			} catch(InterruptedException e) {
			}
		}
	}
 
	


 

 
}	