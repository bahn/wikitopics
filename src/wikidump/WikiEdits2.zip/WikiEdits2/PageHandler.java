import java.util.Date;


public class PageHandler {
	
	
	
	/* increments the edits for a given period i.e. between the 
	 * range provided by the user
	 */
	public  final void incrementEdits( Page page) {
		page.setEdits(page.getEdits()+1);
	}
	
	public  final void incrementTotalAndDayEdits(Page page, Date timestamp) {
		
		String dateText = DateUtilWiki.parseTextFromDate(timestamp); 
		
		if(!page.getDateMapCounts().containsKey(dateText)) {
			page.getDateMapCounts().put(dateText, 0l);
		}
		Long lastVal = page.getDateMapCounts().get(dateText);
		page.getDateMapCounts().put(dateText, lastVal+1);
		this.incrementTotalEdits(page);
	}
 
	/* increments the edit done before the end data but from after the absoulte start*/
	public  final void incrementTotalEdits(Page page) {
		page.setTotalEdits(page.getTotalEdits()+1);
	}
 

}
