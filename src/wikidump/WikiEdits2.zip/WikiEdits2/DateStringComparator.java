import java.util.Comparator;


public class DateStringComparator implements  Comparator<String>{
	
	public int compare(String first, String second) {
		return 1;
	}

}
