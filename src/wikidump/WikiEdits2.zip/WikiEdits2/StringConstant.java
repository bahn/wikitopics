
public  class StringConstant {
	
	public static final String TIME_FORMAT_STRING = "HH:mm:ss";
	public  static final String BEGIN_DATE_PROPERTY_KEY = "begin.date";
	public static final String END_DATE_PROPERTY_KEY = "end.date";
	public static final String MINIMUM_EDITS_PROPERTY_KEY = "min.edits";
	public static final String SORTABLE = " sortable";
	public static final String LIMIT_PROPERTY_KEY = "limit";
	public static final String YEARMONTH_FORMAT_STRING = "yyyy-MM";
	public static final String DATE_FORMAT_STRING = YEARMONTH_FORMAT_STRING + "-dd";
	
	

}
