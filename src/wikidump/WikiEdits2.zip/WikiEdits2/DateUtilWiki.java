import java.text.SimpleDateFormat;
import java.util.Date;


public class DateUtilWiki {
	
		private static StringConstant _SC ;
		private static final SimpleDateFormat WIKI_DATE = new SimpleDateFormat(_SC.DATE_FORMAT_STRING);;
		
		
	
		
	
	
		public static final String parseTextFromDate(Date timestamp) {
		
		return WIKI_DATE.format(timestamp); 
		
	}
		
	

}
